document.addEventListener("keydown", function(event) {
      if (event.keyCode === 13) {
    document.getElementById("launchevent").click();
   }
  });