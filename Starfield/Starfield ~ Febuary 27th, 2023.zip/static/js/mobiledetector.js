      if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|OperaMini/i.test(navigator.userAgent) ) {
      window.location.href = "https://owlpentest.com/mobile-error";
      }