# Galaxy
An interstellar Proxy Site!


# Features
- Ab Cloak on default (i will add setting soon)
- sexy ui
- Blacklisting ip's (inspired from nebula)
- Official site makes site unblocked on ls ig




# Deployment
[![Deploy to Heroku](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/remade/heroku.svg)](https://heroku.com/deploy/?template=https://github.com/Calco-Proxy/Galaxy)
[![Run on Replit](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/remade/replit.svg)](https://replit.com/github/Calco-Proxy/Galaxy)
[![Remix on Glitch](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/remade/glitch.svg)](https://glitch.com/edit/#!/import/github/Calco-Proxy/Galaxy)
